@ECHO OFF
cd worldbuilder
start Launcher.exe
exit