WORLDBUILDER OFFLINE EDITION - READ ME


IMPORTANT NOTICE

Do not rename, rearrange, move, or delete any of the files or folders for this game. Doing so will cripple the game.

The game most likely will not load and play when played from an internet browser unless installed into and played from a local server. If playing without install fails, local server program XAMPP recommended.




METHODS OF PLAY

This game can be played from your internet browser, or by the included EXE (see instructions below).

You must have Shockwave Player installed to play the game from your internet browser.

Version requirements are unknown. This game has been tested to work in Shockwave Players 10 through 12.

If you are having trouble running this game in Shockwave Players 10 and 12, run Shockwave10-12XtrasInstall.vbs to patch those Shockwave installations (Windows users only).




-- HOW TO INSTALL INTO XAMPP --
(Only required in playing without installation fails.)

1. XAMPP must be installed.

2. Windows users can run Installer.vbs to guide you through the installation process. Alternately, manually copy the "worldbuilder" folder (in the folder with this file) to the top level server folder (xampp/htdocs/).




-- HOW TO PLAY WITHOUT INSTALL --

HOW TO OPEN IN AN INTERNET BROWSER:
(Most-likely, this method will fail, but if it doesn't, you won't require installation.)

Open the "Launcher" HTML Document (Launcher.html) in the same folder as this file in your internet browser.




HOW TO OPEN EXE:

Open "Launcher" batch file (Launcher.bat).




-- HOW TO PLAY WITH INSTALL --
(Installation required. XAMPP must first be run. Only the Apache program must be run. Unless you run it as a service, you will have to re-run XAMPP every time Apache is stopped [i.e. when you turn off your computer].)

Open the "Launcher-Installed" HTML Document (Launcher-Installed.html) in the same folder as this file in your internet browser.

Alternately, enter:
http://localhost/worldbuilder/Launcher.html
In your internet browser URL box.





CHEATS

This game saves progress by an editable Shockwave Pref file. Note that the game may not recognize the file has been edited.




PLEASE NOTE

This offline version of WorldBuilder is NOT official and was not made available by The LEGO Group or the producers of this game.
This game was produced for The LEGO Group by Gamelab.
All of the files for this game are the property of The LEGO Group and possibly the producers of this game, and as such please treat the game with respect.
All files for this game are in their original unaltered state; no modifications were made.
This copy was created to preserve this game for the future.